// Axl Dain | Shape Game | 3 Sept 2024
import processing.sound.*;
SoundFile collide;
int x, y, score, tx, ty, tw, speed, shapeDist;
PImage bg1, user1, Target1;

void setup() { // setup runs once at startup
  size(1470,980);
  background(128);
  collide = new SoundFile(this, "brtt.wav");
  bg1 = loadImage("bg1.jpg");
  user1 = loadImage("user1.png");
  Target1 = loadImage("point.png");
  score();
  x = 100;
  y = 100;
  score = 0;
  tx = width/2;
  ty = width/2;
  tw = 150;
  speed = 0;
  shapeDist = 0;
  
}
void draw() { // draw runs at 30fps loop
  shapeDist = int(dist(x,y,tx,ty)<10+tw/2);
  println(shapeDist);
  frameRate(speed + 20);
  background(bg1);
  target();
  score();
  fill(111, 16, 115);
  stroke(100);
  //ellipse(x, y, 20, 20);
  imageMode(CENTER);
  user1.resize(100,100);
  image(user1,x,y);
  if (keyPressed) {
    if (key == 'W') {
      y = y - 20;
    } else if (key == 'S') {
      y = y + 20;
    } else if (key == 'A') {
      x = x - 20;
    } else if (key == 'D') {
      x = x + 20;
    }
  }
  
  //if(x < 1) {
  //  x = width;
  //}
  //if(x>width-1) {
  //  x = 1;
  //}
}

void keyPressed() {
  if (keyPressed) {
    if (key == 'w') {
      y = y - 10;
    } else if (key == 's') {
      y = y + 10;
    } else if (key == 'a') {
      x = x - 10;
    } else if (key == 'd') {
      x = x + 10;
    }
    if (key == CODED) {
      if (keyCode == UP) {
        y = y - 10;
      } else if (keyCode == DOWN) {
        y = y + 10;
      } else if (keyCode == LEFT) {
        x = x - 10;
      } else if (keyCode == RIGHT) {
        x = x + 10;
      }
    }
  }
}

void score() {
  rectMode(CENTER);
  fill(128,128);
  rect(width/2,20,width,40);
  fill(0);
  textSize(30);
  text("Score:" + score, 20,30);
  if(dist(x,y,tx,ty)<40) {
    collide.play();
    tx = int(random(width));
    ty = int(random(height));
    score = score + 10;
    tw = 150;
    speed = speed + 1;
  }
}
void target() {
  fill(255);
  Target1 = loadImage("point.png");
  Target1.resize(tw,tw);
  image(Target1,tx,ty);
  tw = tw - 1;
  if(tw < 1) {
    gameOver();
  }
}

void gameOver() {
  background(0);
  fill(255);
  text("Game Over!", width/2,height/2);
  noLoop();
}
